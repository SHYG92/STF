package sa.gov.tennis.stf;


import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("News")
public class NewsItem extends ParseObject {
    int photo;
    String title;

    public NewsItem(){

    }

    public NewsItem(int photo, String title){
        this.photo= photo;
        this.title= title;
    }

    public void setName(String title){

        this.title=title;
    }

    public String getTitle(){

        return getString("title");
    }

    public int getPhoto(){

        return R.drawable.news;
    }

    public void setPhoto(int photo){

        this.photo=photo;
    }
}
