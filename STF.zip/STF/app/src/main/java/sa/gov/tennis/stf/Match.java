package sa.gov.tennis.stf;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Matches")
public class Match extends ParseObject{

}
