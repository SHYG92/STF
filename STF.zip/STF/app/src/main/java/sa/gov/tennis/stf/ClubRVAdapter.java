package sa.gov.tennis.stf;

import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class ClubRVAdapter extends RecyclerView.Adapter<ClubRVAdapter.ItemViewHolder>{

    List<ClubItem> clubItems;

    ClubRVAdapter(List<ClubItem> clubItems){

        this.clubItems = clubItems;
    }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item, parent, false);
        ItemViewHolder viewHolder = new ItemViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        holder.title.setText(clubItems.get(position).name);
        holder.photo.setImageResource(clubItems.get(position).photo);
    }

    @Override
    public int getItemCount() {
        return clubItems.size();
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView){
        super.onAttachedToRecyclerView(recyclerView);
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        public final View itemView;
        CardView cv;
        public final TextView title;
        public final ImageView photo;

        ItemViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            cv = (CardView)itemView.findViewById(R.id.cv);
            title = (TextView)itemView.findViewById(R.id.title);
            photo = (ImageView)itemView.findViewById(R.id.photo);
        }
    }

}