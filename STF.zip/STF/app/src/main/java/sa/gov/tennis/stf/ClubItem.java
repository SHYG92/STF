package sa.gov.tennis.stf;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Clubs")
public class ClubItem extends ParseObject {
    int photo;
    String name;

    public ClubItem(){

    }

    public ClubItem(int photo, String name){
        this.photo= photo;
        this.name= name;
    }

    public void setName(String name){

        this.name=name;
    }

    public String getName(){

        return getString("name");
    }

    public int getPhoto(){

        return R.drawable.club;
    }

    public void setPhoto(int photo){

        this.photo=photo;
    }

}
