package sa.gov.tennis.stf;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.List;

public class TournamentDetailsActivity extends AppCompatActivity {

    String title;
    TextView tour_name, winner, runner, third;
    Button previous;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tournament_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tour_name = (TextView) findViewById(R.id.tour_name);
        winner = (TextView) findViewById(R.id.winner);
        runner = (TextView) findViewById(R.id.runner);
        third = (TextView) findViewById(R.id.third);
        previous = (Button) findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, PreviousTourActivity.class);
                intent.putExtra("title", title);
                context.startActivity(intent);
            }
        });

        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        tour_name.setText("title");

        /*ParseQuery<Match> query = ParseQuery.getQuery("Matches");
        query.whereEqualTo("tour_name", title);
        query.findInBackground(new FindCallback<Match>() {
            @Override
            public void done(List<Match> objects, ParseException e) {
                if (e != null) {
                    Toast.makeText(TournamentDetailsActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                }
                for (Match match : objects){

                }
            }
        });*/

    }

}
