package sa.gov.tennis.stf;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class SearchResultsActivity extends AppCompatActivity {

    private RecyclerView search_rv;
    private LinearLayoutManager search_rv_lm;
    private List<NewsItem> results;
    private NewsRVAdapter adapter;
    private String title, id;
    private String[] ids;
    private int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        results = new ArrayList<NewsItem>();
        search_rv = (RecyclerView) findViewById(R.id.sr_rv);
        search_rv.setHasFixedSize(true);
        search_rv_lm = new LinearLayoutManager(getBaseContext());
        search_rv.setLayoutManager(search_rv_lm);
        adapter = new NewsRVAdapter(results);
        search_rv.setAdapter(adapter);
        initializeResults();

        search_rv.addOnItemTouchListener(
                new RecyclerItemClickListener(getBaseContext(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Handle item click
                        NewsRVAdapter.ItemViewHolder holder = new NewsRVAdapter.ItemViewHolder(view);
                        title = (String) holder.title.getText();
                        id = ids[position];
                        Context context = view.getContext();
                        Intent intent = new Intent(context, ResultDetailsActivity.class);
                        intent.putExtra("title", title);
                        intent.putExtra("id", id);
                        context.startActivity(intent);
                    }
                })
        );

    }

    private void initializeResults(){
        ParseQuery<NewsItem> query = ParseQuery.getQuery("News");
        query.whereContains("content", SearchActivity.search);
        query.addDescendingOrder("date");
        query.findInBackground(new FindCallback<NewsItem>() {
            @Override
            public void done(List<NewsItem> list, ParseException e) {
                if (e != null) {
                    Toast.makeText(SearchResultsActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                }
                if (list == null) {
                    Toast.makeText(SearchResultsActivity.this, "لا توجد نتائج", Toast.LENGTH_SHORT).show();
                }
                ids = new String[list.size()];
                for (NewsItem item : list) {
                    NewsItem newItem = new NewsItem(R.drawable.news, item.getTitle());
                    ids[i] = item.getObjectId();
                    i++;
                    results.add(newItem);
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}
