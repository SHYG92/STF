package sa.gov.tennis.stf;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends AppCompatActivity {

    private RecyclerView news_rv;
    private LinearLayoutManager news_rv_lm;
    public List<NewsItem> news_list;
    private NewsRVAdapter adapter;
    private String title, id;
    private String[] ids;
    private int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        news_list = new ArrayList<NewsItem>();
        news_rv = (RecyclerView) findViewById(R.id.news_rv);
        news_rv.setHasFixedSize(true);
        news_rv_lm = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        news_rv.setLayoutManager(news_rv_lm);
        adapter = new NewsRVAdapter((news_list));
        news_rv.setAdapter(adapter);
        initializeNews();

        news_rv.addOnItemTouchListener(
                new RecyclerItemClickListener(getBaseContext(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Handle item click
                        ClubRVAdapter.ItemViewHolder holder = new ClubRVAdapter.ItemViewHolder(view);
                        title = (String) holder.title.getText();
                        id = ids[position];
                        Context context = view.getContext();
                        Intent intent = new Intent(context, NewsDetailsActivity.class);
                        intent.putExtra("title", title);
                        intent.putExtra("id", id);
                        context.startActivity(intent);
                    }
                })
        );
    }

    private void initializeNews(){

        ParseQuery<NewsItem> query = ParseQuery.getQuery("News");
        query.addDescendingOrder("date");
        query.findInBackground(new FindCallback<NewsItem>() {
            @Override
            public void done(List<NewsItem> list, ParseException e) {
                if (e != null) {
                    Toast.makeText(NewsActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                }
                ids = new String[list.size()];
                for (NewsItem item : list) {
                    NewsItem newItem = new NewsItem(item.getPhoto(), item.getTitle());
                    ids[i] = item.getObjectId();
                    news_list.add(newItem);
                    i++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}