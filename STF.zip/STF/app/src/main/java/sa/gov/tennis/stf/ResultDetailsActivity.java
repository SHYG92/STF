package sa.gov.tennis.stf;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.squareup.picasso.Picasso;

public class ResultDetailsActivity extends AppCompatActivity {

    String title, id, url;
    ImageView result_photo;
    TextView result_title, content;
    ParseFile photo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        result_photo = (ImageView) findViewById(R.id.result_photo);
        result_title = (TextView) findViewById(R.id.result_title);
        content = (TextView) findViewById(R.id.result_content);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        id = intent.getStringExtra("id");

        ParseQuery<ParseObject> query = ParseQuery.getQuery("News");
        query.whereEqualTo("title", title);
        query.getInBackground(id, new GetCallback<ParseObject>() {
            public void done(ParseObject object, ParseException e) {
                if (object != null) {
                    result_title.setText(object.getString("title"));
                    photo = object.getParseFile("photo");
                    url = photo.getUrl();
                    Picasso.with(result_photo.getContext()).load(url).resize(375, 300).into(result_photo);
                    content.setText(object.getString("content"));
                } else {
                    Toast.makeText(getApplicationContext(), title + " not found", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}
