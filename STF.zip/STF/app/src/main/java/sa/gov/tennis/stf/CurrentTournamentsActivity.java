package sa.gov.tennis.stf;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class CurrentTournamentsActivity extends AppCompatActivity {

    private RecyclerView ct_rv;
    private LinearLayoutManager ct_rv_lm;
    private List<TournamentItem> c_tournaments;
    private TourRVAdapter adapter;
    private String[] ids;
    private String title;
    private int i=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_tournaments);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        c_tournaments = new ArrayList<TournamentItem>();
        ct_rv = (RecyclerView) findViewById(R.id.ct_rv);
        ct_rv.setHasFixedSize(true);
        ct_rv_lm = new LinearLayoutManager(getBaseContext());
        ct_rv.setLayoutManager(ct_rv_lm);
        adapter = new TourRVAdapter(c_tournaments);
        ct_rv.setAdapter(adapter);
        initializeCT();

        ct_rv.addOnItemTouchListener(
                new RecyclerItemClickListener(getBaseContext(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Handle item click
                        ClubRVAdapter.ItemViewHolder holder = new ClubRVAdapter.ItemViewHolder(view);
                        title = (String) holder.title.getText();
                        Context context = view.getContext();
                        Intent intent = new Intent(context, TournamentDetailsActivity.class);
                        intent.putExtra("title", title);
                        context.startActivity(intent);
                    }
                })
        );
    }

    private void initializeCT(){
        ParseQuery<TournamentItem> query = ParseQuery.getQuery("CurrentTournaments");
        query.addDescendingOrder("date");
        query.findInBackground(new FindCallback<TournamentItem>() {
            @Override
            public void done(List<TournamentItem> list, ParseException e) {
                if (e != null) {
                    Toast.makeText(CurrentTournamentsActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                }
                ids = new String[list.size()];
                for (TournamentItem item : list) {
                    TournamentItem newItem = new TournamentItem(R.drawable.tournment, item.getName());
                    ids[i] = item.getObjectId();
                    c_tournaments.add(newItem);
                    i++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}
