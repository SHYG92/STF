package sa.gov.tennis.stf;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class ClubsActivity extends AppCompatActivity {

    private RecyclerView tc_rv;
    private LinearLayoutManager tc_rv_lm;
    private List<ClubItem> clubs_list;
    private ClubRVAdapter adapter;
    private String name, id;
    private String[] ids;
    private int i = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clubs);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ids = new String[53];
        clubs_list = new ArrayList<ClubItem>();
        tc_rv = (RecyclerView) findViewById(R.id.tc_rv);
        tc_rv.setHasFixedSize(true);
        tc_rv_lm = new LinearLayoutManager(getBaseContext());
        tc_rv.setLayoutManager(tc_rv_lm);
        adapter = new ClubRVAdapter(clubs_list);
        tc_rv.setAdapter(adapter);
        initializeClubs();

        tc_rv.addOnItemTouchListener(
                new RecyclerItemClickListener(getBaseContext(), new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Handle item click
                        ClubRVAdapter.ItemViewHolder holder = new ClubRVAdapter.ItemViewHolder(view);
                        name = (String) holder.title.getText();
                        id = ids[position];
                        Context context = view.getContext();
                        Intent intent = new Intent(context, ClubDetailsActivity.class);
                        intent.putExtra("name", name);
                        intent.putExtra("id", id);
                        context.startActivity(intent);
                    }
                })
        );

    }

    private void initializeClubs(){
        ParseQuery<ClubItem> query = ParseQuery.getQuery("Clubs");
        query.addAscendingOrder("ID");
        query.findInBackground(new FindCallback<ClubItem>() {
            @Override
            public void done(List<ClubItem> list, ParseException e) {
                if (e != null) {
                    Toast.makeText(ClubsActivity.this, "Error " + e, Toast.LENGTH_SHORT).show();
                }
                for (ClubItem club : list) {
                    ClubItem newClubItem = new ClubItem(R.drawable.clubs, club.getName());
                    ids[i] = club.getObjectId();
                    clubs_list.add(newClubItem);
                    i++;
                    adapter.notifyDataSetChanged();
                }
            }
        });
    }

}
