package sa.gov.tennis.stf;


import com.parse.Parse;
import com.parse.ParseObject;

public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();

        ParseObject.registerSubclass(ClubItem.class);
        ParseObject.registerSubclass(NewsItem.class);
        ParseObject.registerSubclass(TournamentItem.class);
        ParseObject.registerSubclass(Match.class);
        Parse.initialize(this, "CHkjYPwdixN1WQOwoSOzc17mMluhfno7GT7L4qZo", "yerLGdFgITczV46Kr8r4hhE2NEEB0165n1RKTi3V");
    }
}
