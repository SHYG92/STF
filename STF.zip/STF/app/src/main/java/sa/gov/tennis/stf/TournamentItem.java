package sa.gov.tennis.stf;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("CurrentTournaments")
public class TournamentItem extends ParseObject{

    int photo;
    String name;

    public TournamentItem(){

    }

    public TournamentItem(int photo, String name){
        this.photo= photo;
        this.name= name;
    }

    public void setName(String name){

        this.name=name;
    }

    public String getName(){

        return getString("name");
    }

    public int getPhoto(){

        return R.drawable.tournment;
    }

    public void setPhoto(int photo){

        this.photo=photo;
    }
}
